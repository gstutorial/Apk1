import 'dart:io';
import 'package:excel/excel.dart';
import '../models/employee.dart';
import '../models/column_config.dart';

class ExcelService {
  /// Reads an XLSX file and returns a map of empNo -> Employee
  /// using the provided ColumnConfig.
  static Map<String, Employee> parseFile(
    File file,
    ColumnConfig config,
  ) {
    final bytes = file.readAsBytesSync();
    final excel = Excel.decodeBytes(bytes);

    final sheet = excel.sheets.values.first;
    final rows = sheet.rows;

    final Map<String, Employee> result = {};

    for (int i = config.dataStartRow; i < rows.length; i++) {
      final row = rows[i];

      final empNoCell   = _cellValue(row, config.empNoColumn);
      final empNameCell = _cellValue(row, config.empNameColumn);

      if (empNoCell == null || empNameCell == null) continue;

      final empNo   = empNoCell.trim();
      final empName = empNameCell.trim();

      if (empNo.isEmpty || empName.isEmpty) continue;

      // Skip accidental header rows that slipped through
      if (empNo.toLowerCase() == 'emp no' ||
          empNo.toLowerCase() == 'emp no.' ||
          empNo.toLowerCase() == 'empno') continue;

      result[empNo] = Employee(empNo: empNo, empName: empName);
    }

    return result;
  }

  static String? _cellValue(List<Data?> row, int colIndex) {
    if (colIndex >= row.length) return null;
    final cell = row[colIndex];
    if (cell == null) return null;
    final v = cell.value;
    if (v == null) return null;
    return v.toString();
  }

  /// Parses "EU Jan 2025" style month from file name.
  static ({String monthName, int year})? parseMonthFromName(String fileName) {
    final regex = RegExp(r'EU\s+([A-Za-z]+)\s+(\d{4})', caseSensitive: false);
    final match = regex.firstMatch(fileName);
    if (match == null) return null;
    return (monthName: match.group(1)!, year: int.parse(match.group(2)!));
  }

  static int? monthSortValue(String fileName) {
    final months = {
      'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4,
      'may': 5, 'jun': 6, 'jul': 7, 'aug': 8,
      'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12,
    };
    final parsed = parseMonthFromName(fileName);
    if (parsed == null) return null;
    final abbr = parsed.monthName.substring(0, 3).toLowerCase();
    final m = months[abbr];
    if (m == null) return null;
    return parsed.year * 100 + m;
  }
}
