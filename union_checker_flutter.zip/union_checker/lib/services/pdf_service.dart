import 'dart:io';
import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import '../models/employee.dart';

class PdfService {
  static Future<File> generatePdf({
    required String title,
    required List<Employee> employees,
    required String monthName,
  }) async {
    final pdf = pw.Document();

    // Header gradient colors
    const blue = PdfColor(0.145, 0.388, 0.922); // #2563eb
    const cyan = PdfColor(0.024, 0.714, 0.831); // #06b6d4

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(20),
        header: (ctx) => _buildHeader(title, monthName, employees.length, blue, cyan),
        footer: (ctx) => _buildFooter(ctx, blue, cyan),
        build: (ctx) => [
          pw.SizedBox(height: 8),
          pw.TableHelper.fromTextArray(
            headers: ['S.No.', 'Employee Name', 'Emp. No.'],
            data: List.generate(
              employees.length,
              (i) => [
                '${i + 1}',
                employees[i].empName,
                employees[i].empNo,
              ],
            ),
            headerStyle: pw.TextStyle(
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.white,
              fontSize: 10,
            ),
            headerDecoration: const pw.BoxDecoration(color: blue),
            rowDecoration: const pw.BoxDecoration(),
            oddRowDecoration: const pw.BoxDecoration(
              color: PdfColor(0.957, 0.961, 0.980),
            ),
            cellStyle: const pw.TextStyle(fontSize: 9),
            cellPadding: const pw.EdgeInsets.symmetric(
              horizontal: 6,
              vertical: 5,
            ),
            columnWidths: {
              0: const pw.FixedColumnWidth(35),
              1: const pw.FlexColumnWidth(3),
              2: const pw.FlexColumnWidth(2),
            },
          ),
        ],
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$title.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  static pw.Widget _buildHeader(
    String title,
    String monthName,
    int total,
    PdfColor blue,
    PdfColor cyan,
  ) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        // Top gradient bar
        pw.Container(
          height: 40,
          decoration: pw.BoxDecoration(
            gradient: pw.LinearGradient(colors: [blue, cyan]),
            borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4)),
          ),
          child: pw.Padding(
            padding: const pw.EdgeInsets.symmetric(horizontal: 12),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text(
                  'Employees Union — N.F. Railway',
                  style: pw.TextStyle(
                    color: PdfColors.white,
                    fontWeight: pw.FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                pw.Text(
                  'App by Gobind Sharma',
                  style: const pw.TextStyle(
                    color: PdfColors.white,
                    fontSize: 8,
                  ),
                ),
              ],
            ),
          ),
        ),
        pw.SizedBox(height: 8),
        // Title card
        pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            color: const PdfColor(0.973, 0.980, 0.992),
            borderRadius: const pw.BorderRadius.all(pw.Radius.circular(6)),
            border: pw.Border.all(color: const PdfColor(0.863, 0.863, 0.863)),
          ),
          child: pw.Column(
            children: [
              pw.Text(
                title,
                style: pw.TextStyle(
                  color: blue,
                  fontSize: 16,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
              pw.SizedBox(height: 4),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('Month: $monthName',
                      style: const pw.TextStyle(fontSize: 10)),
                  pw.Text('Total Members: $total',
                      style: const pw.TextStyle(fontSize: 10)),
                ],
              ),
            ],
          ),
        ),
        pw.SizedBox(height: 6),
      ],
    );
  }

  static pw.Widget _buildFooter(pw.Context ctx, PdfColor blue, PdfColor cyan) {
    return pw.Container(
      margin: const pw.EdgeInsets.only(top: 8),
      height: 22,
      decoration: pw.BoxDecoration(
        gradient: pw.LinearGradient(colors: [blue, cyan]),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(4)),
      ),
      child: pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 10),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('NF Railway Employees Union',
                style: const pw.TextStyle(
                    color: PdfColors.white, fontSize: 8)),
            pw.Text(
                'Page ${ctx.pageNumber} of ${ctx.pagesCount}',
                style: const pw.TextStyle(
                    color: PdfColors.white, fontSize: 8)),
          ],
        ),
      ),
    );
  }
}
