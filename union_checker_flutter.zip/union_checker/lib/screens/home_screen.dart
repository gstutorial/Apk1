import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import '../models/column_config.dart';
import '../models/employee.dart';
import '../services/excel_service.dart';
import '../services/pdf_service.dart';

enum AppState { upload, loading, results }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  AppState _appState = AppState.upload;

  File? _oldFile;
  File? _newFile;

  Map<String, Employee> _oldMap = {};
  Map<String, Employee> _newMap = {};

  List<Employee> _removed = [];
  List<Employee> _added   = [];
  List<Employee> _total   = [];

  String _monthLabel = '';

  final TextEditingController _searchCtrl = TextEditingController();
  List<({Employee emp, bool isMember})> _searchResults = [];
  bool _searched = false;

  String? _expandedCard; // 'total' | 'removed' | 'added'

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  // ─── FILE PICKING ──────────────────────────────────────────────────────────

  Future<void> _pickFile(bool isOld) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (result == null || result.files.single.path == null) return;
    setState(() {
      if (isOld) {
        _oldFile = File(result.files.single.path!);
      } else {
        _newFile = File(result.files.single.path!);
      }
    });
  }

  // ─── COMPARE ───────────────────────────────────────────────────────────────

  Future<void> _compare() async {
    if (_oldFile == null || _newFile == null) {
      _toast('⚠️ Please select both XLSX files', isError: true);
      return;
    }

    final oldVal = ExcelService.monthSortValue(_oldFile!.uri.pathSegments.last);
    final newVal = ExcelService.monthSortValue(_newFile!.uri.pathSegments.last);
    if (oldVal != null && newVal != null && oldVal > newVal) {
      _toast('⚠️ Wrong file order! Upload the older month first.', isError: true);
      return;
    }

    setState(() => _appState = AppState.loading);

    try {
      final config = await ColumnConfig.load();

      final oldMap = await Future.microtask(
          () => ExcelService.parseFile(_oldFile!, config));
      final newMap = await Future.microtask(
          () => ExcelService.parseFile(_newFile!, config));

      final removed = <Employee>[];
      final added   = <Employee>[];

      for (final entry in oldMap.entries) {
        if (!newMap.containsKey(entry.key)) removed.add(entry.value);
      }
      for (final entry in newMap.entries) {
        if (!oldMap.containsKey(entry.key)) added.add(entry.value);
      }

      final parsed = ExcelService.parseMonthFromName(
          _newFile!.uri.pathSegments.last);
      final label = parsed != null
          ? '${parsed.monthName} ${parsed.year}'
          : '';

      setState(() {
        _oldMap     = oldMap;
        _newMap     = newMap;
        _removed    = removed;
        _added      = added;
        _total      = newMap.values.toList();
        _monthLabel = label;
        _searchCtrl.clear();
        _searchResults = [];
        _searched      = false;
        _expandedCard  = null;
        _appState      = AppState.results;
      });
    } catch (e) {
      setState(() => _appState = AppState.upload);
      _toast('❌ Error reading files: $e', isError: true);
    }
  }

  // ─── SEARCH ────────────────────────────────────────────────────────────────

  void _search() {
    final q = _searchCtrl.text.toLowerCase().trim();
    if (q.isEmpty) {
      _toast('⚠️ Enter an employee name or number', isError: true);
      return;
    }
    final seen = <String>{};
    final results = <({Employee emp, bool isMember})>[];

    for (final e in _newMap.values) {
      if (e.empNo.toLowerCase().contains(q) ||
          e.empName.toLowerCase().contains(q)) {
        if (seen.add(e.empNo)) results.add((emp: e, isMember: true));
      }
    }
    for (final e in _oldMap.values) {
      if (e.empNo.toLowerCase().contains(q) ||
          e.empName.toLowerCase().contains(q)) {
        if (seen.add(e.empNo)) results.add((emp: e, isMember: false));
      }
    }

    setState(() {
      _searchResults = results;
      _searched = true;
    });
  }

  void _clearSearch() {
    setState(() {
      _searchCtrl.clear();
      _searchResults = [];
      _searched = false;
    });
  }

  // ─── PDF ───────────────────────────────────────────────────────────────────

  Future<void> _downloadPdf(String title, List<Employee> emps) async {
    if (emps.isEmpty) {
      _toast('No records to export', isError: true);
      return;
    }
    try {
      _toast('📄 Generating PDF…');
      final file = await PdfService.generatePdf(
        title: title,
        employees: emps,
        monthName: _monthLabel,
      );
      await OpenFilex.open(file.path);
    } catch (e) {
      _toast('❌ PDF error: $e', isError: true);
    }
  }

  Future<void> _sharePdf(String title, List<Employee> emps) async {
    if (emps.isEmpty) {
      _toast('No records to share', isError: true);
      return;
    }
    try {
      _toast('📄 Generating PDF…');
      final file = await PdfService.generatePdf(
        title: title,
        employees: emps,
        monthName: _monthLabel,
      );
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: title,
      );
    } catch (e) {
      _toast('❌ Share error: $e', isError: true);
    }
  }

  // ─── TOAST ─────────────────────────────────────────────────────────────────

  void _toast(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold)),
      backgroundColor: isError ? const Color(0xFFDC2626) : const Color(0xFF059669),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 3),
    ));
  }

  // ─── BACK ──────────────────────────────────────────────────────────────────

  void _goBack() {
    setState(() {
      _appState = AppState.upload;
      _oldFile  = null;
      _newFile  = null;
      _searchCtrl.clear();
      _searchResults = [];
      _searched      = false;
      _expandedCard  = null;
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.5,
            colors: [Color(0xFF1E3A8A), Color(0xFF0F172A), Color(0xFF020617)],
            stops: [0.0, 0.4, 1.0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 20),
                  child: _buildBody(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Employees Union',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  'Membership Checker',
                  style: TextStyle(
                    color: Color(0xFF93C5FD),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Column Settings',
            onPressed: () async {
              await Navigator.pushNamed(context, '/settings');
            },
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.15)),
              ),
              child: const Icon(Icons.tune, color: Colors.white, size: 22),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: switch (_appState) {
        AppState.upload  => _buildUploadView(),
        AppState.loading => _buildLoadingView(),
        AppState.results => _buildResultsView(),
      },
    );
  }

  // ─── UPLOAD VIEW ───────────────────────────────────────────────────────────

  Widget _buildUploadView() {
    return Column(
      key: const ValueKey('upload'),
      children: [
        const SizedBox(height: 6),
        const Text(
          'Compare Monthly Union Member XLSX Files',
          textAlign: TextAlign.center,
          style: TextStyle(color: Color(0xFFCBD5E1), fontSize: 13),
        ),
        const SizedBox(height: 16),
        _uploadCard(
          label: 'OLD Month XLSX File',
          file: _oldFile,
          onTap: () => _pickFile(true),
        ),
        const SizedBox(height: 12),
        _uploadCard(
          label: 'NEW Month XLSX File',
          file: _newFile,
          onTap: () => _pickFile(false),
        ),
        const SizedBox(height: 16),
        _compareButton(),
        const SizedBox(height: 10),
        _settingsHintRow(),
      ],
    );
  }

  Widget _uploadCard({
    required String label,
    required File? file,
    required VoidCallback onTap,
  }) {
    final picked = file != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
            decoration: BoxDecoration(
              color: picked
                  ? const Color(0xFFDCFCE7).withOpacity(0.92)
                  : const Color(0xFFECFDF5).withOpacity(0.85),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: picked
                    ? const Color(0xFF16A34A)
                    : const Color(0xFF22C55E),
                width: 2.5,
              ),
            ),
            child: Column(
              children: [
                Icon(
                  picked ? Icons.check_circle : Icons.upload_file,
                  color: picked ? const Color(0xFF16A34A) : const Color(0xFF15803D),
                  size: 40,
                ),
                const SizedBox(height: 8),
                Text(
                  picked ? 'File Selected' : 'Tap to Upload',
                  style: const TextStyle(
                    color: Color(0xFF0F172A),
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  picked
                      ? file.uri.pathSegments.last
                      : 'No file selected',
                  style: const TextStyle(
                    color: Color(0xFF475569),
                    fontSize: 12,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _compareButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: _compare,
        icon: const Icon(Icons.compare_arrows, size: 22),
        label: const Text(
          '📑  Compare Files',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF2563EB),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          elevation: 6,
        ),
      ),
    );
  }

  Widget _settingsHintRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.info_outline, color: Color(0xFF64748B), size: 14),
        const SizedBox(width: 6),
        const Text(
          'Sheet columns changed? Tap ',
          style: TextStyle(color: Color(0xFF64748B), fontSize: 12),
        ),
        InkWell(
          onTap: () => Navigator.pushNamed(context, '/settings'),
          child: const Text(
            'Settings',
            style: TextStyle(
              color: Color(0xFF60A5FA),
              fontSize: 12,
              fontWeight: FontWeight.w700,
              decoration: TextDecoration.underline,
              decorationColor: Color(0xFF60A5FA),
            ),
          ),
        ),
      ],
    );
  }

  // ─── LOADING VIEW ──────────────────────────────────────────────────────────

  Widget _buildLoadingView() {
    return const SizedBox(
      key: ValueKey('loading'),
      height: 300,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFF38BDF8)),
            SizedBox(height: 20),
            Text(
              'Processing Files…',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── RESULTS VIEW ──────────────────────────────────────────────────────────

  Widget _buildResultsView() {
    return Column(
      key: const ValueKey('results'),
      children: [
        const SizedBox(height: 12),
        _buildSearchBar(),
        if (_searched) ...[
          const SizedBox(height: 12),
          _buildSearchResults(),
        ],
        const SizedBox(height: 14),
        _statCard(
          id: 'total',
          icon: Icons.groups,
          iconColor: const Color(0xFF2563EB),
          iconBg: const LinearGradient(
              colors: [Color(0xFF2563EB), Color(0xFF60A5FA)]),
          title: 'Total Members',
          count: _total.length,
          employees: _total,
          showPdfButtons: false,
        ),
        const SizedBox(height: 10),
        _statCard(
          id: 'removed',
          icon: Icons.person_remove_outlined,
          iconColor: const Color(0xFFEF4444),
          iconBg: const LinearGradient(
              colors: [Color(0xFFDC2626), Color(0xFFEF4444)]),
          title: 'Removed Employees',
          count: _removed.length,
          employees: _removed,
          showPdfButtons: true,
          pdfTitle: 'Removed Members List',
        ),
        const SizedBox(height: 10),
        _statCard(
          id: 'added',
          icon: Icons.person_add_outlined,
          iconColor: const Color(0xFF22C55E),
          iconBg: const LinearGradient(
              colors: [Color(0xFF16A34A), Color(0xFF4ADE80)]),
          title: 'Employees Added',
          count: _added.length,
          employees: _added,
          showPdfButtons: true,
          pdfTitle: 'Newly Added Members List',
        ),
        const SizedBox(height: 12),
        _backButton(),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(50),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.15),
                  blurRadius: 15,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                const SizedBox(width: 14),
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    onSubmitted: (_) => _search(),
                    style: const TextStyle(color: Color(0xFF1E293B), fontSize: 16),
                    decoration: const InputDecoration(
                      hintText: 'Search by name or emp no…',
                      hintStyle: TextStyle(color: Color(0xFFA0AEC0)),
                      border: InputBorder.none,
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: _search,
                  child: Container(
                    margin: const EdgeInsets.all(5),
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: const Color(0xFF6D28D9),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: const Icon(Icons.search, color: Colors.white, size: 20),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _clearSearch,
          child: const Icon(Icons.close, color: Colors.white, size: 26),
        ),
      ],
    );
  }

  Widget _buildSearchResults() {
    if (_searchResults.isEmpty) {
      return const Center(
        child: Text(
          'No matching employees found.',
          style: TextStyle(color: Color(0xFF94A3B8)),
        ),
      );
    }
    return Column(
      children: _searchResults.map((r) {
        final isMember = r.isMember;
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.emp.empName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        )),
                    const SizedBox(height: 4),
                    Text('Emp No: ${r.emp.empNo}',
                        style: const TextStyle(
                          color: Color(0xFFCBD5E1),
                          fontSize: 13,
                        )),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: isMember
                      ? const Color(0xFF22C55E).withOpacity(0.15)
                      : const Color(0xFFEF4444).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isMember
                        ? const Color(0xFF22C55E).withOpacity(0.3)
                        : const Color(0xFFEF4444).withOpacity(0.3),
                  ),
                ),
                child: Text(
                  isMember ? 'Member: YES' : 'Member: NO',
                  style: TextStyle(
                    color: isMember
                        ? const Color(0xFF4ADE80)
                        : const Color(0xFFF87171),
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _statCard({
    required String id,
    required IconData icon,
    required Color iconColor,
    required Gradient iconBg,
    required String title,
    required int count,
    required List<Employee> employees,
    required bool showPdfButtons,
    String pdfTitle = '',
  }) {
    final isExpanded = _expandedCard == id;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.10),
            Colors.white.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.20),
            blurRadius: 25,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header row
          InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: () => setState(() =>
                _expandedCard = isExpanded ? null : id),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      gradient: iconBg,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: Colors.white, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                  ),
                  Text(
                    '$count',
                    style: const TextStyle(
                      color: Color(0xFF38BDF8),
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(width: 8),
                  AnimatedRotation(
                    turns: isExpanded ? 0.5 : 0.0,
                    duration: const Duration(milliseconds: 250),
                    child: const Icon(Icons.keyboard_arrow_down,
                        color: Color(0xFFCBD5E1)),
                  ),
                ],
              ),
            ),
          ),

          // Expandable list
          AnimatedSize(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeInOut,
            child: isExpanded
                ? Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(14, 0, 14, 0),
                        height: 1,
                        color: Colors.white.withOpacity(0.1),
                      ),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxHeight: 260),
                        child: employees.isEmpty
                            ? const Padding(
                                padding: EdgeInsets.all(16),
                                child: Text('No records.',
                                    style: TextStyle(
                                        color: Color(0xFF94A3B8))),
                              )
                            : ListView.builder(
                                shrinkWrap: true,
                                padding: const EdgeInsets.all(10),
                                itemCount: employees.length,
                                itemBuilder: (_, i) {
                                  final e = employees[i];
                                  return Container(
                                    margin: const EdgeInsets.only(bottom: 6),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 14, vertical: 10),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          e.empName,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 14,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          'Emp No.: ${e.empNo}',
                                          style: const TextStyle(
                                            color: Color(0xFF94A3B8),
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                      ),
                      if (showPdfButtons)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                          child: Row(
                            children: [
                              Expanded(
                                child: ElevatedButton.icon(
                                  onPressed: () =>
                                      _downloadPdf(pdfTitle, employees),
                                  icon: const Icon(Icons.download, size: 18),
                                  label: const Text('Download PDF',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w800)),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF16A34A),
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 11),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(14)),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              ElevatedButton.icon(
                                onPressed: () =>
                                    _sharePdf(pdfTitle, employees),
                                icon: const Icon(Icons.share, size: 18),
                                label: const Text('Share',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w800)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF2563EB),
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 11, horizontal: 14),
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(14)),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _backButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _goBack,
        icon: const Icon(Icons.arrow_back),
        label: const Text(
          'Back to Uploads',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white,
          side: BorderSide(color: Colors.white.withOpacity(0.2)),
          padding: const EdgeInsets.symmetric(vertical: 15),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18)),
        ),
      ),
    );
  }
}
