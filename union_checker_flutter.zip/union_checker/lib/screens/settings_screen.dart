import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/column_config.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _empNoCtrl;
  late TextEditingController _empNameCtrl;
  late TextEditingController _dataStartCtrl;

  ColumnConfig _config = const ColumnConfig();
  bool _loading = true;
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _empNoCtrl   = TextEditingController();
    _empNameCtrl = TextEditingController();
    _dataStartCtrl = TextEditingController();
    _loadConfig();
  }

  Future<void> _loadConfig() async {
    final cfg = await ColumnConfig.load();
    setState(() {
      _config = cfg;
      _empNoCtrl.text   = (cfg.empNoColumn + 1).toString();
      _empNameCtrl.text = (cfg.empNameColumn + 1).toString();
      _dataStartCtrl.text = (cfg.dataStartRow + 1).toString();
      _loading = false;
    });
  }

  Future<void> _save() async {
    final empNo   = int.tryParse(_empNoCtrl.text);
    final empName = int.tryParse(_empNameCtrl.text);
    final dataRow = int.tryParse(_dataStartCtrl.text);

    if (empNo == null || empNo < 1 ||
        empName == null || empName < 1 ||
        dataRow == null || dataRow < 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter valid column/row numbers (≥ 1)'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final cfg = ColumnConfig(
      empNoColumn:   empNo - 1,
      empNameColumn: empName - 1,
      dataStartRow:  dataRow - 1,
    );
    await cfg.save();
    setState(() {
      _config = cfg;
      _saved = true;
    });
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _saved = false);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('✅ Settings saved!'),
        backgroundColor: Color(0xFF16A34A),
      ),
    );
  }

  void _resetDefaults() {
    setState(() {
      _empNoCtrl.text    = '6';  // col F → display 6
      _empNameCtrl.text  = '7';  // col G → display 7
      _dataStartCtrl.text = '2'; // row 2 → skip header row 1
    });
  }

  @override
  void dispose() {
    _empNoCtrl.dispose();
    _empNameCtrl.dispose();
    _dataStartCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.5,
            colors: [Color(0xFF1E3A8A), Color(0xFF0F172A), Color(0xFF020617)],
            stops: [0.0, 0.4, 1.0],
          ),
        ),
        child: SafeArea(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    _buildAppBar(),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _infoCard(),
                            const SizedBox(height: 16),
                            _columnCard(),
                            const SizedBox(height: 16),
                            _previewCard(),
                            const SizedBox(height: 24),
                            _saveButton(),
                            const SizedBox(height: 10),
                            _resetButton(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          ),
          const Expanded(
            child: Text(
              'Column Settings',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          if (_saved)
            const Icon(Icons.check_circle, color: Color(0xFF4ADE80), size: 26),
        ],
      ),
    );
  }

  Widget _infoCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1E40AF).withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.4)),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline, color: Color(0xFF60A5FA), size: 20),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Configure which Excel sheet columns hold the Employee Number and Employee Name.\n\n'
              'Enter the column number as it appears in Excel (A=1, B=2, C=3 … F=6, G=7 …)\n\n'
              'Default: Emp No = Column 6 (F), Emp Name = Column 7 (G), Data starts at Row 2.',
              style: TextStyle(
                color: Color(0xFF93C5FD),
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _columnCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Sheet Column Mapping',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 16),
          _inputField(
            label: 'Employee Number — Column',
            hint: 'e.g. 6 for Column F',
            controller: _empNoCtrl,
            icon: Icons.tag,
          ),
          const SizedBox(height: 14),
          _inputField(
            label: 'Employee Name — Column',
            hint: 'e.g. 7 for Column G',
            controller: _empNameCtrl,
            icon: Icons.person_outline,
          ),
          const SizedBox(height: 14),
          _inputField(
            label: 'Data Starts at Row',
            hint: 'e.g. 2 (to skip header row 1)',
            controller: _dataStartCtrl,
            icon: Icons.table_rows_outlined,
          ),
        ],
      ),
    );
  }

  Widget _inputField({
    required String label,
    required String hint,
    required TextEditingController controller,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFFCBD5E1),
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFF2563EB).withOpacity(0.25),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: const Color(0xFF60A5FA), size: 20),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ValueListenableBuilder<TextEditingValue>(
                valueListenable: controller,
                builder: (_, val, __) {
                  final n = int.tryParse(val.text);
                  final letter = n != null && n >= 1
                      ? '  → ${ColumnConfig.columnLetter(n - 1)}'
                      : '';
                  return TextField(
                    controller: controller,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    decoration: InputDecoration(
                      hintText: hint,
                      hintStyle: TextStyle(
                        color: Colors.white.withOpacity(0.3),
                        fontSize: 13,
                      ),
                      suffixText: letter,
                      suffixStyle: const TextStyle(
                        color: Color(0xFF38BDF8),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.08),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0xFF2563EB),
                          width: 1.5,
                        ),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 12,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _previewCard() {
    final empNoN   = int.tryParse(_empNoCtrl.text);
    final empNameN = int.tryParse(_empNameCtrl.text);
    final rowN     = int.tryParse(_dataStartCtrl.text);

    String status;
    Color statusColor;

    if (empNoN == null || empNameN == null || rowN == null ||
        empNoN < 1 || empNameN < 1 || rowN < 1) {
      status = '⚠️ Invalid settings — enter numbers ≥ 1';
      statusColor = const Color(0xFFFCA5A5);
    } else if (empNoN == empNameN) {
      status = '⚠️ Emp No and Emp Name cannot be the same column!';
      statusColor = const Color(0xFFFCA5A5);
    } else {
      status =
          'Reading Emp No from column ${ColumnConfig.columnLetter(empNoN - 1)} '
          'and Emp Name from column ${ColumnConfig.columnLetter(empNameN - 1)}, '
          'starting at row $rowN.';
      statusColor = const Color(0xFF86EFAC);
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.25),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Preview',
            style: TextStyle(
              color: Color(0xFF94A3B8),
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            status,
            style: TextStyle(
              color: statusColor,
              fontSize: 13,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _saveButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: _save,
        icon: const Icon(Icons.save_outlined),
        label: const Text(
          'Save Settings',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF2563EB),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          elevation: 4,
        ),
      ),
    );
  }

  Widget _resetButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _resetDefaults,
        icon: const Icon(Icons.refresh),
        label: const Text(
          'Reset to Defaults (F, G, Row 2)',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white70,
          side: BorderSide(color: Colors.white.withOpacity(0.2)),
          padding: const EdgeInsets.symmetric(vertical: 13),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
    );
  }
}
