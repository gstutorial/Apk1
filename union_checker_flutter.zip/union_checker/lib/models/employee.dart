class Employee {
  final String empNo;
  final String empName;

  const Employee({required this.empNo, required this.empName});

  @override
  bool operator ==(Object other) =>
      other is Employee && other.empNo == empNo;

  @override
  int get hashCode => empNo.hashCode;
}
