import 'package:shared_preferences/shared_preferences.dart';

class ColumnConfig {
  /// 0-based column index for Employee Number in the sheet
  final int empNoColumn;

  /// 0-based column index for Employee Name in the sheet
  final int empNameColumn;

  /// 0-based row index where actual data starts (after headers)
  final int dataStartRow;

  const ColumnConfig({
    this.empNoColumn = 5,   // column F (index 5) — matches original HTML
    this.empNameColumn = 6, // column G (index 6) — matches original HTML
    this.dataStartRow = 1,  // skip row 0 (header)
  });

  static const _keyEmpNo    = 'col_emp_no';
  static const _keyEmpName  = 'col_emp_name';
  static const _keyDataStart = 'col_data_start';

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyEmpNo, empNoColumn);
    await prefs.setInt(_keyEmpName, empNameColumn);
    await prefs.setInt(_keyDataStart, dataStartRow);
  }

  static Future<ColumnConfig> load() async {
    final prefs = await SharedPreferences.getInstance();
    return ColumnConfig(
      empNoColumn:   prefs.getInt(_keyEmpNo)    ?? 5,
      empNameColumn: prefs.getInt(_keyEmpName)  ?? 6,
      dataStartRow:  prefs.getInt(_keyDataStart) ?? 1,
    );
  }

  ColumnConfig copyWith({int? empNoColumn, int? empNameColumn, int? dataStartRow}) {
    return ColumnConfig(
      empNoColumn:   empNoColumn   ?? this.empNoColumn,
      empNameColumn: empNameColumn ?? this.empNameColumn,
      dataStartRow:  dataStartRow  ?? this.dataStartRow,
    );
  }

  /// Human-readable column letter (A=0, B=1 … Z=25, AA=26 …)
  static String columnLetter(int index) {
    String result = '';
    int n = index;
    do {
      result = String.fromCharCode(65 + (n % 26)) + result;
      n = n ~/ 26 - 1;
    } while (n >= 0);
    return result;
  }
}
