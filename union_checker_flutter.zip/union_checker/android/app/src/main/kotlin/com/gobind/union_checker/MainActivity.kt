package com.gobind.union_checker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
